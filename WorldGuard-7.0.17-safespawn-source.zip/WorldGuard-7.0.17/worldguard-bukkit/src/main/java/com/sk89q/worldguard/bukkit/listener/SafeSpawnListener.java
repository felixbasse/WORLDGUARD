/*
 * WorldGuard, a suite of tools for Minecraft
 * Copyright (C) sk89q <http://www.sk89q.com>
 * Copyright (C) WorldGuard team and contributors
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package com.sk89q.worldguard.bukkit.listener;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.bukkit.util.Entities;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.Vector;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Implements the behaviour of the flags used by {@code /rg safespawn}:
 * {@code elytra}, {@code rocket-use}, {@code void-height} and {@code void-teleport}.
 */
public class SafeSpawnListener extends AbstractListener {

    private final Set<UUID> pendingVoidTeleports = ConcurrentHashMap.newKeySet();

    public SafeSpawnListener(WorldGuardPlugin plugin) {
        super(plugin);
    }

    private boolean isDenied(Player player, Location location, StateFlag flag) {
        if (Entities.isNPC(player)) {
            return false;
        }
        if (!isRegionSupportEnabled(location.getWorld())) {
            return false;
        }
        LocalPlayer localPlayer = getPlugin().wrapPlayer(player);
        if (WorldGuard.getInstance().getPlatform().getSessionManager().hasBypass(localPlayer, localPlayer.getWorld())) {
            return false;
        }
        RegionQuery query = WorldGuard.getInstance().getPlatform().getRegionContainer().createQuery();
        return !query.testState(BukkitAdapter.adapt(location), localPlayer, flag);
    }

    /* ------------------------------------------------------------------ */
    /* elytra                                                             */
    /* ------------------------------------------------------------------ */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onToggleGlide(EntityToggleGlideEvent event) {
        if (!event.isGliding() || !(event.getEntity() instanceof Player player)) {
            return;
        }
        if (isDenied(player, player.getLocation(), Flags.ELYTRA)) {
            event.setCancelled(true);
            player.sendMessage(Component.text("Elytra ist in diesem Bereich nicht erlaubt.", NamedTextColor.RED));
        }
    }

    /* ------------------------------------------------------------------ */
    /* rockets                                                            */
    /* ------------------------------------------------------------------ */

    @EventHandler(priority = EventPriority.HIGH)
    public void onUseRocket(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getItem() == null || event.getItem().getType() != Material.FIREWORK_ROCKET) {
            return;
        }
        Player player = event.getPlayer();
        if (isDenied(player, player.getLocation(), Flags.ROCKET_USE)) {
            event.setUseItemInHand(Event.Result.DENY);
            player.sendMessage(Component.text("Raketen sind in diesem Bereich nicht erlaubt.", NamedTextColor.RED));
        }
    }

    /* ------------------------------------------------------------------ */
    /* movement: gliding inside a denied region + void teleport           */
    /* ------------------------------------------------------------------ */

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null || from.getWorld() != to.getWorld()) {
            return;
        }
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) {
            return; // only react when the block position changes
        }

        Player player = event.getPlayer();

        // Player flew into a no-elytra area: stop gliding
        if (player.isGliding() && isDenied(player, to, Flags.ELYTRA)) {
            player.setGliding(false);
        }

        // Void teleport: only while falling
        if (to.getY() < from.getY()) {
            checkVoid(player, from, to);
        }
    }

    private void checkVoid(Player player, Location from, Location to) {
        if (Entities.isNPC(player) || !isRegionSupportEnabled(from.getWorld())) {
            return;
        }
        UUID id = player.getUniqueId();
        if (pendingVoidTeleports.contains(id)) {
            return;
        }

        LocalPlayer localPlayer = getPlugin().wrapPlayer(player);
        RegionQuery query = WorldGuard.getInstance().getPlatform().getRegionContainer().createQuery();
        // Use the position the player came from, so it still works for the step that leaves the region
        ApplicableRegionSet set = query.getApplicableRegions(BukkitAdapter.adapt(from));

        Integer height = set.queryValue(localPlayer, Flags.VOID_HEIGHT);
        if (height == null || to.getY() >= height) {
            return;
        }
        com.sk89q.worldedit.util.Location destination = set.queryValue(localPlayer, Flags.VOID_TELEPORT);
        if (destination == null) {
            return;
        }
        Location target = BukkitAdapter.adapt(destination);
        if (target.getWorld() == null) {
            return;
        }

        pendingVoidTeleports.add(id);
        player.setFallDistance(0);
        player.setVelocity(new Vector(0, 0, 0));
        player.teleportAsync(target).whenComplete((success, error) -> {
            pendingVoidTeleports.remove(id);
            if (error == null && Boolean.TRUE.equals(success)) {
                player.sendMessage(Component.text("Du bist ins Void gefallen und wurdest zurueck teleportiert.",
                        NamedTextColor.LIGHT_PURPLE));
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        pendingVoidTeleports.remove(event.getPlayer().getUniqueId());
    }

}
