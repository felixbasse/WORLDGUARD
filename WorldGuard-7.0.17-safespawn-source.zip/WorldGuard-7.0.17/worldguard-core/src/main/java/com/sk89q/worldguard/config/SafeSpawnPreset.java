/*
 * WorldGuard, a suite of tools for Minecraft
 * Copyright (C) sk89q <http://www.sk89q.com>
 * Copyright (C) WorldGuard team and contributors
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package com.sk89q.worldguard.config;

import com.sk89q.util.yaml.YAMLFormat;
import com.sk89q.util.yaml.YAMLProcessor;
import com.sk89q.worldguard.WorldGuard;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * The list of flags that is applied to a region by {@code /rg safespawn <id> on}.
 *
 * <p>The list is stored in {@code plugins/WorldGuard/safespawn.yml} and can be
 * edited by hand or with {@code /rg safespawnflags}. Each entry has the form
 * {@code flagname=value}.</p>
 */
public final class SafeSpawnPreset {

    private static final String NODE = "flags";

    /**
     * Flags that are used when no safespawn.yml exists yet.
     */
    private static final List<String> DEFAULTS = Arrays.asList(
            // Part 1: actions
            "build=deny",
            "block-break=deny",
            "block-place=deny",
            "interact=deny",
            "enderpearl=deny",
            "rocket-use=deny",
            "elytra=deny",
            "wind-charge-burst=deny",
            "invincible=allow",
            "natural-hunger-drain=deny",
            "pvp=deny",
            // Part 2
            "damage-animals=deny",
            "fall-damage=deny",
            "chorus-fruit-teleport=deny",
            "potion-splash=deny",
            "item-drop=deny",
            "item-pickup=deny"
    );

    private SafeSpawnPreset() {
    }

    private static File getFile() {
        return new File(WorldGuard.getInstance().getPlatform().getConfigDir().toFile(), "safespawn.yml");
    }

    /**
     * Load the preset (creates the file with defaults if it is missing).
     *
     * @return flag name to value, in order
     */
    public static synchronized Map<String, String> load() {
        File file = getFile();
        Map<String, String> result = new LinkedHashMap<>();
        boolean existed = file.exists();

        YAMLProcessor config = new YAMLProcessor(file, true, YAMLFormat.EXTENDED);
        try {
            config.load();
        } catch (IOException e) {
            WorldGuard.logger.log(Level.WARNING, "Could not load safespawn.yml", e);
        }

        List<String> entries = config.getStringList(NODE, new ArrayList<>(DEFAULTS));
        for (String entry : entries) {
            int idx = entry.indexOf('=');
            if (idx <= 0 || idx == entry.length() - 1) {
                continue;
            }
            result.put(entry.substring(0, idx).trim().toLowerCase(), entry.substring(idx + 1).trim());
        }

        if (!existed) {
            write(result);
        }
        return result;
    }

    /**
     * Write the given preset to disk.
     *
     * @param flags flag name to value
     * @return true if saving worked
     */
    public static synchronized boolean write(Map<String, String> flags) {
        YAMLProcessor config = new YAMLProcessor(getFile(), true, YAMLFormat.EXTENDED);
        try {
            config.load();
        } catch (IOException ignored) {
        }
        List<String> entries = new ArrayList<>();
        for (Map.Entry<String, String> e : flags.entrySet()) {
            entries.add(e.getKey() + "=" + e.getValue());
        }
        config.setHeader(
                "# Flags, die /rg safespawn <region> on automatisch setzt.",
                "# Format: flagname=wert   (z.B. build=deny)",
                "# Bearbeiten per Hand oder mit /rg safespawnflags add|remove|list");
        config.setProperty(NODE, entries);
        return config.save();
    }

}
